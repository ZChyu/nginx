$(document).ready(function(){
	$(".change").click(function(){
		var changei=$(this).attr("changei");
		if(changei=="money"){
			window.location.href="../money/money.jsp";
		}
	})
})