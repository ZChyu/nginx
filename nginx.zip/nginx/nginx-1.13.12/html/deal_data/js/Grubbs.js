$(document).ready(function(){
	$("#submit1").click(function(){
		var file=$("#showfile1").val();
		if(file==""){
			alert0("错误","没有选择文件！");
			openfile("showfile1");
			return;
		}
		var file_type=$("#file-type").val();
		var hasheader=$("#hasheader").val();
		var zhouqi=$("#zhouqi").val();
		var maxtime=$("#maxtime").val();
		var split;
		if(file_type=="csv"){
			split=",";
		}else if(file_type=="tsv"){
			split="\t";
		}else{
			split=" ";
		}
		var data={file:file,split:split,hasheader:hasheader,zhouqi:zhouqi,save:parseInt($("#savereport").val()),
				alpha:parseInt($("#alpha").val())};
		$.post("../GrubbsServlet",$.toJSON(data),function(data){
			var datao=JSON.parse(data);
			if(datao.state="ok"){
				report0(datao);
				$("#resultfile").val("result"+datao.timestr+".csv");
				$("#reportfile").val("report"+datao.timestr+".report");
				alert0("提示","处理成功，报告已更新！");
			}else{
				alert0("错误",data0.state);
			}
		});
	})
})