function setSize(){
	var height=$(window).height()-51;
	var width=$(window).width()-205;
	$("#menu").css("height",height);
	$("#menu-left").css("height",height);
	$("#menu-left1").css("height",height);
	$("#menu-left2").css("height",height);
	$("#menu-right").css("height",height);
	$("#menu-right").css("width",width);
	$("#iframe").css("height",height);
	
}
$(document).ready(function(){
	
	var fetchstr=$("#fetchstr").attr("value");
	setSize();
	$(window).resize(function(){   
		setSize();
	});
	$(".headeri").click(function(){
		if(runing==true){
			return;
		}
		location.href=$(this).attr("hrefa");
	})
	$("#loginout").click(function(){
		if(runing==true){
			return;
		}
		$.post("/LoginOut",{},function(){
			location.href="/menu/index.jsp";
		})
	})
	var left2_now=$("#menu-left-2-1");
	var left1_now=$("#menu-left1");
	$(".menu-left1").click(function(){
		if(runing==true){
			return;
		}
		left1_now.css("background-color","");
		left1_now=$(this);
		left1_now.css("background-color","#00c1de")
		left2_now.stop().hide();
		left2_now=$("#menu-left-2-"+$(this).attr("index"));
		
		left2_now.stop().show();
	})
	
	var menu_left2_now;
	$(".menu-left2").click(function(){
		if(runing==true){
			return;
		}
			if(menu_left2_now!=null){
				menu_left2_now.css({"background-color":"","color":""});
			}
			menu_left2_now=$(this);
			menu_left2_now.css({"background-color":"#00c1de","color":"white"});
			$("#menu-left-1-"+$(this).parent().attr("index")).click();
			$("#iframe").attr("src",$(this).attr("hrefa"));
	})

})
$(function () { $("[data-toggle='tooltip']").tooltip(); });