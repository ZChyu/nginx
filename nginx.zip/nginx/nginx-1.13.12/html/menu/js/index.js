var banner=[{lable:"数据处理",img:"/images/brain4.png"},
		{lable:"机器学习",img:"/images/man1.png"},
		{lable:"预测",img:"/images/e4.jpg"},
		{lable:"建模",img:"/images/e5.jpg"},
		{lable:"神经网络&SVM",img:"/images/brain2.png"}];
var banner_now=0;
var banner_num=5;
function change_right(){
	banner_now++;
	banner_now=banner_now>=banner_num?0:banner_now;
	change_banner(banner_now);
}
function change_left(){
	banner_now--;
	banner_now=banner_now<0?banner_num-1:banner_now;
	change_banner(banner_now);
}
function change_banner(banner_index){
	var bannern=banner[banner_now];
	$("#banner-left-1").html(bannern.lable);
	$("#banner-img").attr("src",bannern.img);
}
$(document).ready(function(){
	$("#login").click(function(){
		location.href="/menu/login.jsp";
	})
	$("#go-right").click(function(){
		change_right();
	})
	$("#go-left").click(function(){
		change_left();
	})
	var banneri_now;
	var header_now;
	$(".headers").mouseenter(function(){
		if(banneri_now!=null){
		 banneri_now.stop().hide();
		 header_now.css("border-bottom","black 5px");
		}
		$(this).css("border-bottom","#00c1de solid 5px");
		banneri_now=$("#banneri"+$(this).attr("index"));
		banneri_now.stop().show();
		header_now=$(this);
	})
	$(".banneri").mouseleave(function(){
		$(this).stop().hide();
		banneri_now=null;
		header_now.css("border-bottom","black 5px");
	})
	$(".headersn").mouseenter(function(){
		if(banneri_now!=null){
			 banneri_now.stop().hide();
			 banneri_now=null;
			 header_now.css("border-bottom","black 5px");
		}
	})
	$(".hrefa").click(function(){
		location.href=$(this).attr("hrefa");
	})
	setInterval(change_right,20000);
	
})