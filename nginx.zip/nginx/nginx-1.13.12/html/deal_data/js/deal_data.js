$(document).ready(function(){
	var show=0;
	var lastresult;
	$("#result_show").click(function(){
		if(show++%2==0){
			$("#resultshowa").show();
		var rf=$("#resultfile").val();
		if(rf!=""&&rf!=lastresult){
			$.get("../RushFile/"+fetchstr+"/"+rf,function(data){
				$("#resultshowa").html(data);
				lastresult=rf;
			})
			
		}
		}else{
			$("#resultshowa").hide();
		}
	})
	$("#result_download").click(function(){
		var rf=$("#resultfile").val();
		if(rf!=""){
			window.open("../RushFile/"+fetchstr+"/"+rf);
		}
	})
	$("#report_download").click(function(){
		var rf=$("#reportfile").val();
		if(rf!=""){
			window.open("../RushFile/"+fetchstr+"/"+rf);
		}
	})
	$("#report-menu").click(function(){
		var fn=$("#reportfile").val();
		if(fn!=""){
			report("../RushFile/"+fetchstr+"/"+fn);
		}
		
	})
	$("#choicereport").click(function(){
		openfile("reportfile");
	})
	$("#choicefile1").click(function(){
		openfile("showfile1");
	})
	$("#submit1").click(function(){
		var file=$("#showfile1").val();
		if(file==""){
			alert0("错误","没有选择文件！");
			openfile("showfile1");
			return;
		}
		var file_type=$("#file-type").val();
		var hasheader=$("#hasheader").val();
		var zhouqi=$("#zhouqi").val();
		var maxtime=$("#maxtime").val();
		var figureshow=$("#figureshow").val();
		var datashow=$("#datashow").val();
		$.post("../XiaoweileServlet",{zhouqi:zhouqi,fetchstr:fetchstr,filename:file,filetype:file_type,hasheader:hasheader},function(data){
			
			var datao=JSON.parse(data);
			if(datao.success==1){
			report("../RushFile/"+fetchstr+"/"+datao.report);
			$("#resultfile").val(datao.result);
			$("#reportfile").val(datao.report);
			alert0("错误","处理成功，报告已更新！");
			}else{
				alert0("错误","配置错误！");
			}
		});
	})
})
function report(file){
	$.getJSON(file,function(data){
		addrowTable("report_size",data.headers,data.size,data.zhouqi,data.sizex);
		addrowTable("report_mean",data.headers,data.mean,data.zhouqi,data.sizex);
		addrowTable("report_var",data.headers,data.Var,data.zhouqi,data.sizex);
		addrowTable("report_std",data.headers,data.std,data.zhouqi,data.sizex);
		addNaNTable("report_nan",data.nan);
	})
}
function addNaNTable(pannel_id,data){
	var str="<table class=\"table table-hover\"><thead><tr><th>行号</th><th>列号</th><th>原值<th>超出界限</th>"
		+"</tr></thead><tbody>";
	for(var i=0;i<data.length;i++){
		str+="<tr>"
			for(var j=0;j<data[i].length;j++){
				str+="<td>"+data[i][j]+"</td>";
			}
		str+="</tr>";
	}
	str+="</tbody></table>";
	$("#"+pannel_id).html(str);
}
function addrowTable(pannel_id,headers,data,zhouqi,sizex){
	var str="<table class=\"table table-hover\"><thead><tr>";
	var leny=headers.length;
	var lenx=data.length;
	str+=("<th>索引</th>");
	for(var i=0;i<leny;i++){
		str+=("<th>"+headers[i]+"</th>");
	}
	str+=("</tr></thead><tbody>");
	for(var i=0;i<lenx-1;i++){
		str+=("<tr><td>"+(i*zhouqi)+"~"+(i*zhouqi+zhouqi-1)+"</td>");
		for(var j=0;j<leny;j++){
			str+=("<td>"+data[i][j]+"</td>");
		}
		str+="</tr>";
	}
	var startindex;
	if(zhouqi>sizex){
		startindex=0;
	}
	else{
		startindex=(sizex-zhouqi);
	}
	str+=("<tr><td>"+startindex+"~"+(sizex-1)+"</td>");
	for(var j=0;j<leny;j++){
		str+=("<td>"+data[lenx-1][j]+"</td>");
	}
	
	str+="</tr></tbody></table>";
	$("#"+pannel_id).html(str);
}