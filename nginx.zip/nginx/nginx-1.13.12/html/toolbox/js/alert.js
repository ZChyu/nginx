function alert0(titlestr,bodystr){
	$("#myModalLabel").html(titlestr);
	$("#modal-body").html(bodystr);
	$('#myModal').modal({keyboard: true})
}
function alert0(titlestr,bodystr,footstr){
	$("#myModalLabel").html(titlestr);
	$("#modal-body").html(bodystr);
	$("#modal-footer").html(footstr);
	$('#myModal').modal({keyboard: true})
}