$(document).ready(function(){
	$(".hrefa").click(function(){
		location.href=$(this).attr("hrefa");
	})
	$("#login").click(function(){
		var namelen=$("#name").val().length;
		if(namelen<4||namelen>15){
			alert0("错误","用户名长度不能小于4,不能大于15！");
			return;
		}
		var pswlen=$("#password").val().length;
		if(pswlen<6||pswlen>15){
			alert0("错误","密码长度不能小于6！,不能大于15！");
			return;
		}
		if(!($("#tongyi").is(':checked'))){
			 alert0("错误","你还没同意并已阅读《新时代之光网站协议》！");
			  return;
		}
		
		$.post("/Login",{name:$("#name").val(),psw:$("#password").val()},function(innertext){
			
			var data=JSON.parse(innertext);
			if(data.state=="ok"){
				location.href=url;
					return;
			}else{
				alert0("错误",data.state);
					return;
			}
			  
		});
		
	})
		
})