var runing=false;
function run(){
	if(runing){
		alert0("错误","<span style=\"color:red;font-size:30px\">当前有任务正在运行！<span>");
		return false;
	}
	$("#runing").stop().show(500);
	runing=true;
	return true;
}
function run_end(){
	runing=false;
	$("#runing").stop().hide(500);
}