var url="/FreeNetworkWebServlet";
$(document).ready(function(){
	
	$("#trainsubmit").click(function(){
		if($("#showfile").val()==""){
			alert("还没有选择训练集文件！");
			openfile("showfile");
			return;
		}
		var cs=$("#nural_ceng").val();
		var state;
		if($("#showfile1").val()==""){
			state="t";
		}else{
			state="tc";
		}
		var split;
		var file_type=$("#file-type").val();
		if(file_type=="csv"){
			split=",";
		}else if(file_type=="tsv"){
			split="\t";
		}else{
			split=" ";
		}
		var jsonobj={network_style:"elman",state:state,psi:parseFloat($("#psi").val()),split:split,ci:parseInt($("#ci").val()),
				file1:$("#showfile").val(),file2:$("#showfile1").val(),
				theLearningRate:parseFloat($("#theLearningRate").val()),theMomentum:parseInt($("#theMomentum").val()),
				greedy:parseInt($("#greedy").val()),hidden:parseInt($("#hidden").val()),maxtime:parseInt($("#maxtime").val()),
				func:parseInt($("#func").val()),normalize:parseInt($("#normalize").val()),keeptrain:parseInt($("#keeptrain").val())};
		if($("#tuihuo").val()==1){
			jsonobj.start_temp=$("#start_temp").val();
			jsonobj.stop_temp=$("#stop_temp").val();
			jsonobj.circles=$("#circles").val();
		
		}else{
			jsonobj.start_temp="NaN";
			jsonobj.stop_temp="NaN";
			jsonobj.circles="NaN";
		}
		if($("#isend").val()==1){
			jsonobj.min_improvement=$("#min_improvement").val();
			jsonobj.tolerate_cycles=$("#tolerate_cycles").val();
		}else{
			jsonobj.min_improvement="NaN";
			jsonobj.tolerate_cycles="NaN";
		}
		net_tc(url,jsonobj,state);
		
	})
	
	
})