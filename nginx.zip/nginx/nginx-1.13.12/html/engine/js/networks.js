$(document).ready(function(){
	$("#shownetwork").click(function(){
		parent.location.href="/engine/control.jsp";
	})
})