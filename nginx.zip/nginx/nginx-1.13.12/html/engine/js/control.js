var obj;
var selected;
var bias_after;
var id_c;
var func_c;
var bias_c;
var deal_c;
var color;
$(document).ready(function(){
	id_c=$("#ID");
	func_c=$("#func");
	func_c.html(funcOption);
	bias_c=$("#bias");
	deal_c=$("#deal");
	deal_c.draggable();
	var height=$(window).height();
	var width=$(window).width();
	$("body").css("height",height);
	$("body").css("width",width);
	$("#login-out").click(function(){
		$.post("/LoginOut",{},function(){
			location.href="/engine/control.jsp";
		})
	})
	$("#login").click(function(){
		location.href="/menu/login.jsp?url=\"/engine/control.jsp\"";
	})
	$("#regist").click(function(){
		location.href="/menu/regist.jsp";
	})
	addnerual("#nerual",3);
	
	draw_network_url("/data/free.net");
	$("#nural_ceng").change(function(){
		var cs=$(this).val();	
		addnerual("#nerual",cs);	
	});
	$("#new").click(function(){
		$("#addnetwork").stop().toggle(500);
	})
	$("#addnetwork").css("top",height/4).css("left",width/3).draggable();
	$("#addnetwork-close").click(function(){
		$("#addnetwork").stop().hide(500);
	})
	$("#import").click(function(){
		$("#import1").stop().toggle(500);
	})
	$("#import-back").click(function(){
		$("#import1").stop().hide(500);
	})
	$(".import").click(function(){
		$("#deal").stop().hide(500);
		draw_network_url($(this).attr("hrefa"));
	})
	$("#help").click(function(){
		window.open("/engine/teach.jsp");
	})
	$("#addnetwork-create").click(function(){
		obj=toJSONObject();
		refresh();
	})
	$("#box").click(function(){
		var name=$("#name").html();
		if(name==null){
			location.href="/menu/login.jsp?url=\"/engine/control.jsp\"";
			return
		}
		file_refresh();
		$("#file-control").stop().toggle(500);
	})
	$("#my-box").click(function(){
		var name=$("#name").html();
		if(name==null){
			location.href="/menu/login.jsp?url=\"/engine/control.jsp\"";
			return
		}
		file_refresh();
		$("#file-control").stop().toggle(500);
	})
	$("#save").click(function(){
		$.post("/SaveNetServlet",$.toJSON(obj),function(inner){
			var data=$.parseJSON(inner);
			var state=data.state;
			if(state=="ok"){
				var name=data.name;
				alert0("成功","<h3 style=\"color:green\">保存成功</h3><h3>文件名:"+name+"</h3>");
			}else if(state=="loginfalse"){
				location.href="/menu/login.jsp?url=\"/engine/control.jsp\"";
			}
		})
	})
	$("#compute").css("left",width-130);
	
	$("#logo").click(function(){
		window.open("/menu/menu.jsp");
	})
	$("#train").click(function(){
		$("#traindiv").stop().toggle(500);
	})
	$("#compute").click(function(){
		$("#computediv").stop().toggle(500);
	})
/*---------------------------------------------------*/
	$("#addlink_button").click(function(){
		var name2=$("#addlink").val();
		var name=id_c.html();
		var comp=compName(name,name2);
		var target,source;
		if(comp==1){
			target=name;
			source=name2;
		}else{
			target=name2;
			source=name;
		}
		if(obj.unlink[target]==null){
			alert0("提示","从"+source+"到"+target+"的链接已存在！");
		}else{
			var index1=obj.unlink[target].indexOf(source);
			if(index1!=-1){
				obj.unlink[target].splice(index1,1);
				
				refresh1();
			}else{
				alert0("提示","从"+source+"到"+target+"的链接已存在！");
			}
		}
	})
	$("#sublink_button").click(function(){
		var target_link=obj.unlink[target];
		var name2=$("#sublink").val();
		var name=id_c.html();
		var comp=compName(name,name2);
		var target,source;
		if(comp==1){
			target=name;
			source=name2;
		}else{
			target=name2;
			source=name;
		}
		if(obj.unlink[target]==null){
			obj.unlink[target]=[];
			obj.unlink[target].push(source);
			
			refresh1();
			return;
		}
		var index1=obj.unlink[target].indexOf(source);
		if(index1==-1){		
			obj.unlink[target].push(source);			
			refresh1();
		}else{
			alert0("提示","从"+source+"到"+target+"的链接不存在!");
		}			
	})
	$("#close-deal").click(function(){
		$("#deal").stop().hide(500);
	})
	$("#delete-deal").click(function(){
		var name=id_c.html();
		deleteObj(name);
		refresh();
	})
	$("#submit-deal").click(function(){
		var name=id_c.html();
		var func=func_c.val();
		var bias=bias_c.val();
		selected.attr("fill",function(d){
			if(name.charAt(0)=='I'){
				if(bias==0){
					return "white";
				}else{
					return "blue";
				}
			}
			if(bias==0&&bias_after!=0){
				var name_l=name+"l";
				d3.selectAll("."+name_l).attr("class",function(){
					var str=$(this).attr("class");
					str=str.replace(name_l,name);
					return str;
				});
				d.f=func;
				obj.fun[name]=func;
				d.bias=bias;
				delete obj.bias[name];
				return color(d.f);
			}else if(bias!=0&&bias_after==0){
				var name_l=name+"l";
				d3.selectAll("."+name).attr("class",function(d){
					var str=$(this).attr("class");
					if(d.target.name==name){
						str=str.replace(name,name_l);
					}
					return str;
				});
				d.f=3;
				obj.fun[name]=3;
				d.bias=bias;
				obj.bias[name]=bias;
				return "white";
			}else if(bias==0){
				d.f=func;
				obj.fun[name]=func;
				return color(func);
			}else{
				d.bias=bias;
				return "white";
			}
		})
		deal_c.stop().hide(500);
	})
})
function compName(name1,name2){
	if(name1==name2){
		return 0;
	}
	var c1=name1.charAt(0);
	var c2=name2.charAt(0);
	if(c1=='I'){
		if(c2=='I'){
			return 0;
		}else{
			return -1;
		}
	}else if(c1=='H'){
		if(c2=='I'){
			return 1;
		}else if(c2="O"){
			return -1;
		}else{
			var str1=name1.split("-")[0];
			var str2=name2.split("-")[0];
			var int1=str1.substring(1,str1.length);
			var int2=str2.substring(1,str2.length);
			if(int1>int2){
				return 1;
			}else if(int1<int2){
				return -1;
			}else{
				return 0;
			}
		}
	}else{
		if(c2=="O"){
			return 0;
		}else{
			return 1;
		}		
	}
}
function file_back(name){
	draw_network_url("/DownloadFileServlet?file="+name);
}
function refresh1(){
	draw_network_obj(obj);
}
function refresh(){
	$("#deal").stop().hide(1);
	draw_network_obj(obj);
}
function deleteObj(name){
	var ceng1;
	var c=name.charAt(0);
	var sp=name.split("-");
	if(c=='I'){
		ceng1=0;
	}else if(c=="O"){
		ceng1=obj.nerual_num.length-1;
	}else{
		ceng1=parseInt(sp[0].substring(1,sp[0].length))+1;
	}
	var index=sp[1];
	obj.nerual_num[ceng1]=obj.nerual_num[ceng1]-1;
}
function draw_network_url(url){
	$.getJSON(url,function(data){
		obj=data;
		draw_network_obj(data);
	})
}
function draw_network_obj(obj){
	 parseTrain();
	nodes =[];
	links=[];
	var nerual_num=obj.nerual_num;
	var unlink=obj.unlink;
	var bias=obj.bias;
	var func=obj.fun;
	var funcNum=6;
	var endi=nerual_num.length-1;
	for(var i=0;i<=endi;i++){
		var start_str;
		var t;
		if(i==0){
			start_str="I-";
			t="input";
		}else if(i==endi){
			start_str="O-";
			t="output"
		}else{
			start_str="H"+(i-1)+"-";
			t="hidden";
		}
		for(var j=0;j<nerual_num[i];j++){
			var node=new Object();
			node.name=start_str+j;
			if(bias[node.name]!=null){
				node.bias=bias[node.name];
			}else{
				node.bias=0;
			}
			if(func[node.name]!=null){
				node.f=func[node.name];
			}else{
				node.f=3;
			}
			nodes.push(node);
		}
	}	
	start1=0;
	start2=nerual_num[0];
	for(var i=0;i<endi;i++){
		for(var k=0;k<nerual_num[i+1];k++){
			var unlin;
			if((unlin=unlink[nodes[start2+k].name])==null){
				unlin=[];
			}
			for(var j=0;j<nerual_num[i];j++){
				var index;
				if((index=unlin.indexOf(nodes[start1+j].name))==-1){
					var link=new Object();
					link.source=nodes[start1+j];
					link.target=nodes[start2+k];
					links.push(link);
				}
			}
		}
		start1+=nerual_num[i];
		start2+=nerual_num[i+1];
	}
	draw_network_nodes("all",nodes,links,nerual_num.length);
}
function draw_network_nodes(draw_id,nodes,links,ceng){
	$("#"+draw_id).html("");
	var height=$(window).height()-70;
	var width=$(window).width()-30;
	color = d3.scale.category20().domain(d3.range(16));
	var funcNum=6;
	var width6=width/6;
	var width3=width/3;
	var width8=width/8;
	var widthi=width/(ceng*2);
	var force = d3.layout.force()
    .nodes(d3.values(nodes))
    .links(links)
    .size([width, height])
    .linkDistance(function(){
    	return Math.random()*widthi+widthi;
    })
    .charge(-2000)
    .on("tick", tick)
    .start();	
	var svg = d3.select("#"+draw_id).append("svg")
    .attr("width", width)
    .attr("height", height);	
	var link = svg.selectAll(".link")
    .data(force.links())
  	.enter().append("line")
  	.attr("stroke","#afafaf")
  	.attr("stroke-width",0.3)
    .attr("class",function(d){
    	if(d.target.bias!=0){
    		return"link "+d.source.name+" "+d.target.name+"l";
    	}else{
    		return "link "+d.source.name+" "+d.target.name;
    	}
    });	
	var node = svg.selectAll(".node")
    .data(force.nodes())
  	.enter().append("g")
    .attr("class", "node")
    .on("mouseover", mouseover)
    .on("mouseout", mouseout)
    .call(force.drag);
	node.append("circle")
	.attr("x",-20)
	.attr("y",-20)
	.attr("r",20)
	.attr("id",function(d){
		d.name;
	})
	.attr("filter",function(d){
			return "url(#f2)";
	})
	.attr("fill",function(d){
		if(d.bias!=0){
			d.func=3;
			return "white";
		}
		var c=d.name.charAt(0);
		if(c=='I'){
			return "blue";
		}else{
			return color(d.f);
		}
	});
	node.append("text")
	.attr("x", -15)
	.attr("dy", "10")
	.text(function(d,i) { return d.name; });
	function tick() {
		node.each(function(d){
			var c=d.name.charAt(0);
			if(c=='O'){
				d.x=width-width6;
			}else if(c=='I'){
				d.x=width6;
			}
		});
		node.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; });
	  	link.attr("x1", function(d) { return d.source.x; })
	      .attr("y1", function(d) { return d.source.y; })
	      .attr("x2", function(d) { return d.target.x; })
	      .attr("y2", function(d) { return d.target.y; });
	}	
	function mouseover() {
		d3.select(this).select("circle").transition()
	    .duration(150)
	    .attr("x",-50)
		.attr("y",-50)
	    .attr("r",50)
	    .attr("dfdf",function(d){
	    	d3.selectAll("."+d.name).attr("stroke","yellow")
	    	.attr("stroke-width",2);
	    	return d.name;
	    });
	}
	function mouseout() {
		d3.select(this).select("circle").transition()
			.duration(350)
			.attr("x",-20)
			.attr("y",-20)
			.attr("r", 20)
			.attr("dfdf",function(d){
				d3.selectAll("."+d.name).attr("stroke","#afafaf")
					.attr("stroke-width",0.3);;
				return d.name;
			});
	}
	
	$("circle").dblclick(function(){
		var name;
		var func;
		var bias;
		var offset=$(this).offset();
		var top=offset.top;
		var left=offset.left;		
		selected=d3.select(this).attr("fd",function(d){
			name=d.name;
			func=d.f;
			bias=d.bias;
		});
		bias_after=bias;
		id_c.html(name);
		func_c.val(func);
		bias_c.val(bias);
		func_c.attr("disabled",false);
		if(bias!=0||name.charAt(0)=='I'){
			func_c.attr("disabled",true);
		}
		deal_c.css("left",left)
				.css("top",top)
				.stop().show(500);
	})
}