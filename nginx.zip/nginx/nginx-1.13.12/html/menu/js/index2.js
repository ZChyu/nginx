$(document).ready(function(){
	$(".index2-banner1")
	
})