funcRight="<option value=\"3\">Linear</option><option value=\"0\" >Sigmod</option><option value=\"1\">Sin</option><option value=\"2\">Tanh</option>"+
"<option value=\"4\">BiPolar</option><option value=\"5\">Log</option></select></td>";
sb1="<tr><td>1</td><td>默认</td><td><select id=\"bias1\"><option value=\"1\">是</option><option value=\"0\">否</option></select></td>"+
"<td>无</td></tr>";
function createFunc(idn){
	var sb="<td><select  id=\""+idn+"\">"+funcRight;
	return sb;
}
function createmid(cs){
	var sb="<tr><td>"+cs+"</td><td><input type=text size=3 value=30 class=\"sjys\" id=\"sjy"+cs+
	"\"/></td><td><select id=\"bias"+cs+"\"><option value=\"1\">是</option><option value=\"0\">否</option></select></td>"+
	
	createFunc("func"+cs)+"</tr>";
	return sb;
}
function createCSshow(cs){
	var sb=sb1;
	for(var i=2;i<cs;i++){
		sb+=createmid(i);
	}
	sb+="<tr><td>"+cs+"</td><td>默认</td><td>否</td>"+
	createFunc("func"+cs)+"</tr>";
	return sb;
}
function addnerual(nerual,cs){
	$(nerual).html(createCSshow(cs));
	$(".sjys").on("blur",function(){
		var cs=$(this).val();
		if(isNaN(cs)||parseInt(cs)!=cs||cs<3||cs>30){
			 $(this).val(8);
			alert0("错误","请填入3~30之间的正整数!");
			return;
		}
	})
}
var url="/FreeNetworkWebServlet";
$(document).ready(function(){
	 addnerual("#nerual",3);
	$("#nural_ceng").change(function(){
		var cs=$(this).val();	
		addnerual("#nerual",cs);
		
	});
	$("#trainsubmit").click(function(){
		if($("#showfile").val()==""){
			alert("还没有选择训练集文件！");
			openfile("showfile");
			return;
		}
		if(!parent.run()){
			return;
		}
		var cs=$("#nural_ceng").val();
		var state;
		if($("#showfile1").val()==""){
			state="t";
		}else{
			state="tc";
		}
		var split;
		var file_type=$("#file-type").val();
		if(file_type=="csv"){
			split=",";
		}else if(file_type=="tsv"){
			split="\t";
		}else{
			split=" ";
		}
		var jsonobj={network_style:"free",state:state,psi:parseFloat($("#psi").val()),split:split,ci:parseInt($("#ci").val()),
				file1:$("#showfile").val(),file2:$("#showfile1").val(),neual_num:[],
				theLearningRate:parseFloat($("#theLearningRate").val()),theMomentum:0,
				greedy:0,neual_num:[],maxtime:parseInt($("#maxtime").val()),
				bias:[],func:[],normalize:parseInt($("#normalize").val()),keeptrain:parseInt($("#keeptrain").val())};
		
		jsonobj.start_temp="NaN";
		jsonobj.stop_temp="NaN";
		jsonobj.circles="NaN";
		if($("#isend").val()==1){
			jsonobj.min_improvement=$("#min_improvement").val();
			jsonobj.tolerate_cycles=$("#tolerate_cycles").val();
		}else{
			jsonobj.min_improvement="NaN";
			jsonobj.tolerate_cycles="NaN";
		}
		jsonobj.neual_num.push(0);
		jsonobj.bias.push(parseInt($("#bias1").val()));
		jsonobj.func.push(-1);
		for(var i=2;i<cs;i++){
			jsonobj.neual_num.push(parseInt($("#sjy"+i).val()));
			jsonobj.bias.push(parseInt($("#bias"+i).val()));
			jsonobj.func.push(parseInt($("#func"+i).val()));
		}
		jsonobj.neual_num.push(0);
		jsonobj.bias.push(0);
		jsonobj.func.push(parseInt($("#func"+cs).val()));
		
		net_tc(url,jsonobj,state);
		
	})
	
	
})