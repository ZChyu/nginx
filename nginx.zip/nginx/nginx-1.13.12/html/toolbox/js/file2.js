var isfile=false;
var file_control=$("#file-control");

function openfile(showid){
	isfile=true;
	getList("files");
	ShowId=showid;
	file_control.stop().show(500);
}
function back0(str){
	$("#"+ShowId).val(str);
	
}
var ShowId;
function file_close(){
	isfile=false;
	file_control.stop().hide(500);
}
function file_toggle(time){
	isfile=false;
	file_control.stop().toggle(time);
}
function file_refresh(){
	getList("files");
}
function getList(ul_id){
	var data;
	if(isfile){
		data={};
	}else{
		data={type:"net"};
	}
	$.post("/FilesListServlet",data,function(innertext){
		var pan=$("#"+ul_id);
		if(innertext=="null"){
			pan.html("<div class='col-md-5 '><h2>无文件！请上传</h2></div>");
			return;
		}
		var filelist=JSON.parse(innertext);
		var filelist0=filelist[0];
		var str="";
		for(var i in filelist0){
			str+="<div class=\"col-md-2 file-list\">"+filelist0[i]+"</div>";
		}
		pan.html(str);
		 bondsGreen("file-list");
	 });
}
var lastfile=null;
function bondsGreen(classname){
	$("."+classname).on("click",(function(){
			if(lastfile!=null){
				lastfile.css("background","#00c1de")
			}
			$(this).css("background","green")
			lastfile=$(this);
			$("#fileselect").val(lastfile.html());
	}))
	$("."+classname).on("dblclick",function(){
		
		if(!isfile){file_back(lastfile.html());}else{back0(lastfile.html());}
		file_close(500);
	})
}
var timeout=false;
function time()  
{  
  if(timeout) return;  
  uploading();  
  setTimeout(time,100); //time是指本身,延时递归调用自己,100为间隔调用时间,单位毫秒  
}  
function upload(){
	timeout=false;
	time();
}
function cl(){
	$("#iframe1").attr("src","");
}
function uploading(){
	var val=$(window.frames["iframe2"].document).find("#success").html();
	if(val=="success"){
		getList("files");
		timeout=true;
		$("#iframe1").attr("src","/toolbox/successed.html");
		$(window.frames["iframe2"].document).find("#success").html("failed");
		setTimeout(cl,2000);
	}
}
function delet(){
	var filenames=$("#fileselect").val();
	lastfile.remove();
	lastfile=null;
	$.post("/DeleteFileServlet",{filename:filenames.toString()},function(innertext){
	 });
}
function clearall(){
	$("#files").empty();
	$.post("/DeleteFileServlet",{all:"all"},function(innertext){
	 });
}
$(document).ready(function(){
	 file_control=$("#file-control");
	file_control.draggable();
	getList("files");
	$("#refresh_file").click(function(){
		getList("files");
	})
	$("#close").click(function(){
		file_control.stop().hide(500);
	})
	$("#filesubmit").click(function(){
		$("#iframe1").attr("src","/toolbox/uploading.html");
		upload();
	})
	$("#delete").click(function(){
		delet();
	})
	$("#clearall").click(function(){
		clearall();
	})
	$("#load").click(function(){
		window.open("/DownloadFileServlet?file="+lastfile.html());
	})
	$("#choice").click(function(){
		
		if(!isfile){
			file_back(lastfile.html());
		}else{
			back0(lastfile.html());
		}
		file_close(500);
	})
})