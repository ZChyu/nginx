$(document).ready(function(){
	var loadstr="http://pan.baidu.com/s/1hs7Jeio";
	$(".list-group-item").click(function(){
		
		$("#video1").attr("src",$(this).attr("hrefa"));
		
		loadstr=$(this).attr("hrefa2");
		$("#video1").load();
		document.getElementById("video1").play();
		$("#titles").html($(this).html());
		
	
	})
	$("#myload").click(function(){
		window.open(loadstr);
	})
	
	
})