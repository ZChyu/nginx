funcOption="<option value=\"16\">随机</option><option value=\"3\">Linear</option><option value=\"0\" >Sigmod</option><option value=\"1\">Sin</option><option value=\"2\">Tanh</option>"+
"<option value=\"4\">ClippedLinear</option><option value=\"5\">Log</option><option value=\"6\">Gaussian</option>"+
"<option value=\"7\">SoftMax</option><option value=\"8\">Ramp</option><option value=\"9\">Elliott</option><option value=\"10\">Bipolar</option>"+
"<option value=\"11\">Step</option><option value=\"12\">BipolarSS</option><option value=\"13\">Competitive</option>"+
"<option value=\"14\">ElliottS</option><option value=\"15\">SigmiodS</option>";
funcRight=funcOption+"</select></td>";
sb1="<tr><td>1</td><td><input type=text size=3 value=5 class=\"sjys\" id=\"sjy1\"/></td><td><select id=\"bias1\"><option value=\"1\">是</option><option value=\"0\">否</option></select></td>"+
"<td>无</td></tr>";
function createFunc(idn){
	var sb="<td><select  id=\""+idn+"\">"+funcRight;
	return sb;
}
function createmid(cs){
	var sb="<tr><td>"+cs+"</td><td><input type=text size=3 value=18 class=\"sjys\" id=\"sjy"+cs+
	"\"/></td><td><select id=\"bias"+cs+"\"><option value=\"1\">是</option><option value=\"0\">否</option></select></td>"+
	
	createFunc("func"+cs)+"</tr>";
	return sb;
}
function createCSshow(cs){
	var sb=sb1;
	for(var i=2;i<cs;i++){
		sb+=createmid(i);
	}
	sb+="<tr><td>"+cs+"</td><td><input type=text size=3 value=2 class=\"sjys\" id=\"sjy"+cs+
	"\"/></td><td>否</td>"+
	createFunc("func"+cs)+"</tr>";
	return sb;
}
function addnerual(nerual,cs){
	$(nerual).html(createCSshow(cs));
	$(".sjys").on("blur",function(){
		var cs=$(this).val();
		if(isNaN(cs)||parseInt(cs)!=cs||cs<3||cs>30){
			 $(this).val(8);
			alert0("错误","请填入3~30之间的正整数!");
			return;
		}
	
	})
	$("#func"+cs).val(3);
}
function toJSONObject(){
	var obj={nerual_num:[],unlink:{},bias:{},fun:{}};
	var cs=$("#nural_ceng").val();
	for(var i=1;i<=cs;i++){
		var num1=parseInt($("#sjy"+i).val());
		var func=parseInt($("#func"+i).val());
		var bias=parseInt($("#bias"+i).val());
		if(i==1){
			func=3
		}
		obj.nerual_num.push(num1);
		var cstr;
		if(i==1){
			cstr="I-";
		}else if(i==cs){
			cstr="O-";
		}else{
			cstr="H"+(i-2)+"-";
		}
		if(func==16){
			for(var j=0;j<num1;j++){
				var f=Math.min(15,parseInt(Math.random()*16));
				if(f!=3){
					obj.fun[cstr+j]=f;
				}
			}
		}else{
			if(f!=3){
				for(var j=0;j<num1;j++){	
					if(func!=3){obj.fun[cstr+j]=func;}
					
				}
			}			
		}
		
		if(bias!=0&&i!=cs){
			obj.bias[cstr+obj.nerual_num[i-1]]=bias;
			obj.nerual_num[i-1]++;
		}
	}
	return obj;
}