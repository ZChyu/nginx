$(document).ready(function(){
	$("#regist").click(function(){
		var yzm=$("#yzm").val();
		if(checkYZM(yzm)){
			if(success_flag[0]&&success_flag[1]&&success_flag[2]&&success_flag[3]){
				$.post("/Regist",{state:"checkyzm",yzm:yzm,psw:$("#password1").val()},function(innertext){
					var data=$.parseJSON(innertext);
					if(data.state!="ok"){
						if(data.state="timesout"){
							$("#yzm-img").attr("src","/images/wrong.png");
							
							alert0("错误","填写失误过多，请重新填写！");
							location.href="/menu/regist.jsp"
						}else{
							$("#yzm-img").attr("src","/images/wrong.png");
							alert0("错误",data.state);
						}
					}else{
						$("#yzm-img").attr("src","/images/right.png");
						alert0("提示","注册成功，请登陆,5秒内自动跳转登录界面");
						setTimeout(login,5000);
						
					}
				})
			}else{
				
				alert0("错误","请完成信息填写！");
			}
		}
		
	})
	var success_flag=[false,false,false,false];
	$("#name").blur(function(){
		var name=$(this).val();
		if(name.length>0){	
			if(checkName(name)){
				$.post("/Regist",{state:"checkname",name:name},function(innertext){
					var data=$.parseJSON(innertext);
					if(data.state!="ok"){
						$(this).val("");
						success_flag[0]=false;
						$("#name-img").attr("src","/images/wrong.png");
						alert0("错误",data.state);
					}else{
						success_flag[0]=true;
						$("#name-img").attr("src","/images/right.png");
					}
				})
			}else{
				$(this).val("");
				success_flag[0]=false;
				$("#name-img").attr("src","/images/wrong.png");
			}
		}
	})
	$("#password1").blur(function(){
		var psw1=$(this).val();
		var psw2=$("#password2").val();
		if(psw1.length>0&&psw2.length>0&&psw2!=psw1){
			$(this).val("");
			$("#psw1-img").attr("src","/images/wrong.png");
			alert0("错误","两次密码输入不一致！");
			success_flag[1]=false;
			return;
		}
		if(psw1.length>0){
			
			if(checkPSW(psw1)){
				success_flag[1]=true;
				$("#psw1-img").attr("src","/images/right.png");
			}else{
				success_flag[1]=false;
				$("#psw1-img").attr("src","/images/wrong.png");
				$(this).val("");
			}
		}
	})
	$("#password2").blur(function(){
		var psw1=$("#password1").val();
		var psw2=$(this).val();
		if(psw1.length>0&&psw2.length>0){
			if(psw2!=psw1){
				$(this).val("");
				success_flag[2]=false;
				$("#psw2-img").attr("src","/images/wrong.png");
				alert0("错误","两次密码输入不一致！");
			}else{
				success_flag[2]=true;
				$("#psw2-img").attr("src","/images/right.png");
			}
			return;
		}
		if(psw1.length==0){
			
			if(checkPSW(psw1)){
				success_flag[2]=true;
				$("#psw2-img").attr("src","/images/right.png");
			}else{
				success_flag[2]=false;
				$("#psw2-img").attr("src","/images/wrong.png");
				$(this).val("");
			}
			
		}
		
	})
	$("#sendyzm").click(function(){
		var mail=$("#mail").val();
		
		if(checkMail(mail)){
			$.post("/Regist",{state:"checkmail",mail:mail},function(innertext){
				var data=$.parseJSON(innertext);
				if(data.state=="ok"){
					success_flag[3]=true;
					alert0("提示","已经向您的邮箱内发送验证码，请注意查收");
					$("#mail-img").attr("src","/images/right.png");
				}else{
					$("#mail").val("");
					success_flag[3]=false;
					$("#mail-img").attr("src","/images/wrong.png");
					alert0("错误",data.state);
				}
			})
		}else{
			success_flag[3]=false;
			$("#mail-img").attr("src","/images/wrong.png");
		}
		
	})
})
function checkMail(mail){
	if(mail.length==0){
		alert0("错误","邮箱不能为空");
		return false;
	}
	var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	if(!reg.test(mail)){
		alert0("错误","输入邮箱不合法！");
		return false;
	}
	return true;
}
function checkPSW(psw){
	if(psw.length<6||psw.length>16){
		alert0("错误","密码长度要在6~16之间，当前密码长度超出范围！");
		return false;
	}
	return true;
}
function checkName(name){
	if(name.length<4||name.length>15){
		alert0("错误","用户名长度需在4~15之间，当前用户名长度超出范围！");
		return false;
	}
	var Regx = /(^[A-Za-z0-9]+$)/;
	if(Regx.test(name)==false){
		alert0("错误","用户名只能由字母和数字组成！");
		return false;
	}
	return true;
}
function checkYZM(yzm){
	if(yzm.length==6&&!isNaN(yzm)){
		return true;
	}else{
		alert0("错误","验证码格式错误！");
	}
}
function login(){
	location.href="/menu/login.jsp";
}