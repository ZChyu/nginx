$(document).ready(function(){
	$("#ntl").click(function(){
		var p=parent;
		if(p==null){
			location.href="http://www.newtimeslight.com";
		}else{
			parent.location.href="http://www.newtimeslight.com";
		}
		
	})
})