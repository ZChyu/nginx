var show=0;
var lastresult;
$(document).ready(function(){
	$("#yucesubmit").click(function(){
		if($("#showfile3").val()==""){
			alert0("错误","没有选择训练集文件.network");
			openfile("showfile3");
			return ;
		}
		if($("#showfile4").val()==""){
			alert("没有选择预测数据文件.csv");
			openfile("showfile4");
			return ;
		}
		if(!parent.run()){
			return;
		}
		var split;
		var file_type=$("#file-type2").val();
		if(file_type=="csv"){
			split=",";
		}else if(file_type=="tsv"){
			split="\t";
		}else{
			split=" ";
		}
		var jsonobj={state:"c",split:split,file1:$("#showfile3").val(),file2:$("#showfile4").val()};
		net_c(url,jsonobj);
	})
	$("#result_show").click(function(){
		if(show++%2==0){
			$("#resultshowa").show();
		var rf=$("#showfile6").val();
		if(rf!=""&&rf!=lastresult){
			$.get("/DownloadFileServlet",{file:rf},function(data){
				$("#resultshowa").html(data);
				lastresult=rf;
			})
		}
		}else{
			$("#resultshowa").hide();
		}
	})
	$("#train_download").click(function(){
		var rf=$("#showfile5").val();
		if(rf!=""){
			window.open("/DownloadFileServlet?file="+rf);
		}
	})

	$("#result_download").click(function(){
		var rf=$("#showfile6").val();
		if(rf!=""){
			window.open("/DownloadFileServlet?file="+rf);
		}
	})
	$("#choicefile").click(function(){
		openfile("showfile");
	})
	$("#choicefile1").click(function(){
		openfile("showfile1");
	})
	$("#choicefile2").click(function(){
		openfile("showfile2");
	})
	$("#choicefile3").click(function(){
		openfile("showfile3");
	})
	$("#choicefile4").click(function(){
		openfile("showfile4");
	})
	$("#choicefile6").click(function(){
		openfile("showfile6");
	})
})

function net_c(url,jsonobj){
	$.post(url,$.toJSON(jsonobj),function(inner){
	
		var data=$.parseJSON(inner);
		if(data.state=="ok"){
			resultfile="result"+timestr+".csv";
			$("#showfile6").val(resultfile);
			var buff1="<span style=\"font-weight:bold;color:#00c1de;\">结果文件:</span>"+resultfile+"<br>";
			alert0("成功","<span style=\"color:green;font-size:20px;;\">计算成功</span><br><span style=\"font-weight:bold;color:#00c1de;\">本次计算消耗:</span>"+data.cost+" 金币！<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">运行时间:</span>"+data.runtime+"ms<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">训练精度:</span>"+data.psi+"<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">训练次数:</span>"+data.ci	+"次<br>"+buff1			
			);
		}else if(data.state=="loginfalse"){
			parent.location.href="/menu/login.jsp";
		}else{
			alert0("错误",data.state);
		}
		parent.run_end();
	});
}

function net_tc(url,jsonobj,state){
	$.post(url,$.toJSON(jsonobj),function(inner){
		var data=$.parseJSON(inner);
		if(data.state=="ok"){
			var timestr=data.timestr;
			var trainedfile="trained"+timestr+".network";
			$("#showfile3").val(trainedfile);
			$("#showfile5").val(trainedfile);
			var resultfile;				
			var buff1="<span style=\"font-weight:bold;color:#00c1de;\">模型文件:</span>"+trainedfile+"<br>";
			if(state=="tc"){
				resultfile="result"+timestr+".csv";
				$("#showfile6").val(resultfile);
				buff1+="<span style=\"font-weight:bold;color:#00c1de;\">结果文件:</span>"+resultfile+"<br>";
			}else{
				resultfile="";
			}
			alert0("成功","<span style=\"color:green;font-size:20px;;\">计算成功</span><br><span style=\"font-weight:bold;color:#00c1de;\">本次计算消耗:</span>"+data.cost+" 金币！<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">运行时间:</span>"+data.runtime+"ms<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">训练精度:</span>"+data.psi+"<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">训练次数:</span>"+data.ci	+"次<br>"+buff1			
			);			
		}else if(data.state=="loginfalse"){
			parent.location.href="/menu/login.jsp";
		}else{
			alert0("错误",data.state);
		}
		parent.run_end();
	});
}

	