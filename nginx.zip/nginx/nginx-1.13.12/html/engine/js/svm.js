var url="/SVMWebServlet";
$(document).ready(function(){
	$("#trainsubmit").click(function(){
		if($("#showfile").val()==""){
			alert("还没有选择训练集文件！");
			openfile("showfile");
			return;
		}
		
		var state;
		if($("#showfile1").val()==""){
			state="t";
		}else{
			state="tc";
		}
		var split;
		var file_type=$("#file-type").val();
		if(file_type=="csv"){
			split=",";
		}else if(file_type=="tsv"){
			split="\t";
		}else{
			split=" ";
		}
		var jsonobj={state:state,psi:parseFloat($("#psi").val()),split:split,ci:parseInt($("#ci").val()),
				file1:$("#showfile").val(),file2:$("#showfile1").val(),maxtime:parseInt($("#maxtime").val()),
				normalize:parseInt($("#normalize").val()),keeptrain:parseInt($("#keeptrain").val()),
				svmType:parseInt($("#svmType").val()),kernelType:parseInt($("#kernelType").val())};
		if($("#isend").val()==1){
			jsonobj.min_improvement=$("#min_improvement").val();
			jsonobj.tolerate_cycles=$("#tolerate_cycles").val();
		}else{
			jsonobj.min_improvement="NaN";
			jsonobj.tolerate_cycles="NaN";
		}
		net_tc(url,jsonobj,state);
	})
	
	
})