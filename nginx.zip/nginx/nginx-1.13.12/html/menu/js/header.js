$(document).ready(function(){
	$(".hrefa").click(function(){
		location.href=$(this).attr("hrefa");
	})
})