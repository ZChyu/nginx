$(document).ready(function(){
	$(".headerlable").click(function(){
		location.href=$(this).attr("hrefa");
	})
	$("#logoimg").click(function(){
		location.href=$(this).attr("hrefa");
	})
})