
var url="/NetworkBaseWebServlet";

$(document).ready(function(){
	$("#compute-start").click(function(){
		if($("#model-file").val()==""){
			alert("还没有选择模型文件！");
			openfile("model-file");
			return;
		}
		if($("#compute-file").val()==""){
			alert("还没有选择计算集文件");
			openfile("compute-file");
			return;
		}
		if(!run()){
			return;
		}
		
		var split;
		var file_type=$("#file-type2").val();
		if(file_type=="csv"){
			split=",";
		}else if(file_type=="tsv"){
			split="\t";
		}else{
			split=" ";
		}
		var obj1=new Object();
		obj1.state="c";
		obj1.network_style="free";
		obj1.file1=$("#model-file").val();
		obj1.file2=$("#compute-file").val();
		obj1.split=split;
		net_c(url,obj1);
		
	})
	$("#train-start").click(function(){
		if($("#train-file").val()==""){
			alert("还没有选择训练集文件！");
			openfile("train-file");
			return;
		}
		if(!run()){
			return;
		}
		var cs=$("#nural_ceng").val();
		var state;
		if($("#test-file").val()==""){
			state="t";
		}else{
			state="tc";
		}
		var split;
		var file_type=$("#file-type").val();
		if(file_type=="csv"){
			split=",";
		}else if(file_type=="tsv"){
			split="\t";
		}else{
			split=" ";
		}
		var obj1=obj;
		obj1.network_style="free";
		obj1.state=state;
		obj1.file1=$("#train-file").val();
		obj1.file2=$("#test-file").val();
		obj1.split=split;
		
		if(obj.isend==0){
			obj1.min_improvement="NaN";
			obj1.tolerate_cycles="NaN";
		}
		if(obj.tuihuo==0){
			obj1.start_temp="NaN";
			obj1.stop_temp="NaN";
			obj1.circles="NaN";
		}
		delete obj1.isend;
		delete obj1.tuihuo;
		var Resilient=$("#Resilient").val();
		obj1.Resilient=Resilient;
		if(Resilient==1){
			obj1.initialUpdate=parseFloat($("#initialUpdate").val());
			obj1.theMaxStep=parseInt($("#theMaxStep").val());
		}else{
			
		}
		net_tc(url,obj1,state);
		
	})
	
	
})

function net_c(url,jsonobj){
	$.post(url,$.toJSON(jsonobj),function(inner){
		
		var data=$.parseJSON(inner);
	
		if(data.state=="ok"){
			var timestr=data.timestr;
			resultfile="result"+timestr+".csv";
			
			var buff1="<span style=\"font-weight:bold;color:#00c1de;\">结果文件:</span>"+resultfile+"<br>";
			alert0("成功","<span style=\"color:green;font-size:20px;;\">计算成功</span><br><span style=\"font-weight:bold;color:#00c1de;\">本次计算消耗:</span>"+data.cost+" 金币！<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">运行时间:</span>"+data.runtime+"ms<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">训练精度:</span>"+data.psi+"<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">训练次数:</span>"+data.ci	+"次<br>"+buff1			
			);
		}else if(data.state=="loginfalse"){
			parent.location.href="/menu/login.jsp";
		}else{
			alert0("错误",data.state);
		}
		run_end();
	});
}


function net_tc(url,jsonobj,state){
	$.post(url,$.toJSON(jsonobj),function(inner){
		var data=$.parseJSON(inner);
		if(data.state=="ok"){
			var timestr=data.timestr;
			var trainedfile="trained"+timestr+".network";

			var resultfile;				
			var buff1="<span style=\"font-weight:bold;color:#00c1de;\">模型文件:</span>"+trainedfile+"<br>";
			if(state=="tc"){
				resultfile="result"+timestr+".csv";
				
				buff1+="<span style=\"font-weight:bold;color:#00c1de;\">结果文件:</span>"+resultfile+"<br>";
			}else{
				resultfile="";
			}
			alert0("成功","<span style=\"color:green;font-size:20px;;\">计算成功</span><br><span style=\"font-weight:bold;color:#00c1de;\">本次计算消耗:</span>"+data.cost+" 金币！<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">运行时间:</span>"+data.runtime+"ms<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">训练精度:</span>"+data.psi+"<br>"+
					"<span style=\"font-weight:bold;color:#00c1de;\">训练次数:</span>"+data.ci	+"次<br>"+buff1			
			);			
		}else if(data.state=="loginfalse"){
			parent.location.href="/menu/login.jsp";
		}else{
			alert0("错误",data.state);
		}
		run_end();
	});
}