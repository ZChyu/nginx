# -*- coding: utf-8 -*-
"""
Created on Fri May  4 09:31:23 2018

@author: lidh
"""

import xlrd
import json

def add_child(table,father,depth):
    if depth>100:
        return 
    nrows = table.nrows  # 行数
    for i in range(1, nrows):
        if(str(table.cell(i,4).value).strip( ) == father['name']):
            child={'name':str(table.cell(i,0).value),"children":[],'nick':str(table.cell(i,1).value),'job':str(table.cell(i,8).value)}
            add_child(table,child,depth+1)
            father["children"].append(child)
data = xlrd.open_workbook('data1.xlsx')
table = data.sheets()[0] 
nrows = table.nrows  # 行数
ncols = table.ncols  # 列数

map3=dict()
map3["name"]="－"
map3["nick"]="－"
map3["job"]="－"
map3["children"]=list()
add_child(table,map3,0)
 


with open("./res.json",'w',encoding='utf-8') as json_file:
    json.dump(map3,json_file,ensure_ascii=False)
    
    
data = xlrd.open_workbook('data2.xlsx')
table = data.sheets()[0] 
nrows = table.nrows  # 行数
ncols = table.ncols  # 列数
map1=dict()
for i in range(1,nrows):
    order=dict()
    order['name']=str(table.cell(i,22).value).strip( )
    order['val']=table.row_values(i);
    map1[table.cell(i,0).value]=order
with open("./order.json",'w',encoding='utf-8') as json_file:
    json.dump(map1,json_file,ensure_ascii=False)
    

    