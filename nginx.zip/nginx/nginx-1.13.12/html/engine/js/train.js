$(document).ready(function(){
	$("#traindiv").draggable();
	$("#computediv").draggable();
	var width=$(window).width();
	$("#computediv").css("left",width-800+"px");
	$("#train-close").click(function(){
		$("#traindiv").stop().hide(500);
	})
	$("#compute-close").click(function(){
		$("#computediv").stop().hide(500);
	})
	$("#test-file-btn").click(function(){
		openfile("test-file");
	})
	$("#model-file-btn").click(function(){
		openfile("model-file");
	})
	$("#train-file-btn").click(function(){
		openfile("train-file");
	})
	$("#compute-file-btn").click(function(){
		openfile("compute-file");
	})
	$("#file-type").change(function(){
		var file_type=$(this).val();
		var split;
		if(file_type=="csv"){
			split=",";
		}else if(file_type=="ksv"){
			split=" ";
		}else{
			split="\t";
		}
		obj.split=split;
	})
	$("#hasheader").change(function(){
		obj.hasheader=parseInt($(this).val());
	})
	$("#keeptrain").change(function(){
		obj.keeptrain=parseInt($(this).val());
	})
	$("#psi").change(function(){
		obj.psi=parseFloat($(this).val());
	})
	$("#ci").change(function(){
		obj.ci=parseInt($(this).val());
	})
	$("#maxtime").change(function(){
		obj.maxtime=parseInt($(this).val());
	})
	$("#theLearningRate").change(function(){
		obj.theLearningRate=parseFloat($(this).val());
	})
	$("#theMomentum").change(function(){
		obj.theMomentum=parseFloat($(this).val());
	})
	$("#greedy").change(function(){
		obj.greedy=parseInt($(this).val());
	})
	$("#tuihuo").change(function(){
		obj.tuihuo=parseInt($(this).val());
	})
	$("#start_temp").change(function(){
		obj.start_temp=parseInt($(this).val());
	})
	$("#stop_temp").change(function(){
		obj.stop_temp=parseInt($(this).val());
	})
	$("#circles").change(function(){
		obj.circles=parseInt($(this).val());
	})
	$("#isend").change(function(){
		obj.isend=parseInt($(this).val());
	})
	$("#min_improvement").change(function(){
		obj.min_improvement=parseFloat($(this).val());
	})
	$("#tolerate_cycles").change(function(){
		obj.tolerate_cycles=parseInt($(this).val());
	})
})
function parseTrain(){
	var split=obj.split;
	if(split==null){
		$("#file-type").val("csv");
		obj.split=",";
	}else{
		if(split==","){
			$("#file-type").val("csv");
		}else if(split=" "){
			$("#file-type").val("ksv");
		}else{
			$("#file-type").val("tsv");
		}
	}
	var hasheader=obj.hasheader;
	if(hasheader==null){
		obj.hasheader=1;
		$("#hasheader").val(1);
	}else{
		$("#hasheader").val(hasheader);
	}
	var normalize=obj.normalize;
	if(normalize==null){
		obj.normalize=1;
		$("#normalize").val(1);
	}else{
		$("#normalize").val(normalize);
	}
	var keeptrain=obj.keeptrain;
	if(keeptrain==null){
		obj.keeptrain=1;
		$("#keeptrain").val(1);
	}else{
		$("#keeptrain").val(keeptrain);
	}
	var psi=obj.psi;
	if(psi==null){
		obj.psi=10E-5;
		$("#psi").val("10E-5");
	}else{
		$("#psi").val(psi);
	}
	var ci=obj.ci;
	if(ci==null){
		obj.ci=1000;
		$("#ci").val(1000);
	}else{
		$("#ci").val(ci);
	}
	var maxtime=obj.maxtime;
	if(maxtime==null){
		obj.maxtime=30;
		$("#maxtime").val(30);
	}else{
		$("#maxtime").val(maxtime);
	}
	var theLearningRate=obj.theLearningRate;
	if(theLearningRate==null){
		obj.theLearningRate=0.00001;
		$("#theLearningRate").val(0.00001);
		
	}else{
		$("#theLearningRate").val(theLearningRate);
	}
	var theMomentum=obj.theMomentum;
	if(theMomentum==null){
		obj.theMomentum=0;
		$("#theMomentum").val(0);
	}else{
		$("#theMomentum").val(theMomentum);
	}
	var greedy=obj.greedy;
	if(greedy==null){
		obj.greedy=0;
		$("#greedy").val(0);
	}else{
		$("#greedy").val(greedy);
	}
	var tuihuo=obj.tuihuo;
	if(tuihuo==null){
		obj.tuihuo=0;
		$("#tuihuo").val(0);
	}else{
		$("#tuihuo").val(tuihuo);
	}
	var start_temp=obj.start_temp;
	if(start_temp==null){		
		obj.start_temp=10;	
		$("#start_temp").val(10);
	}else{
		$("#start_temp").val(start_temp);
	}
	var stop_temp=obj.stop_temp;
	if(stop_temp==null){
		obj.stop_temp=2;
		$("#stop_temp").val(2);
	}else{
		$("#stop_temp").val(stop_temp);
	}
	var circles=obj.circles;
	if(circles==null){
		obj.circles=50;
		$("#circles").val(50);
	}else{
		$("#circles").val(circles);
	}
	var isend=obj.isend;
	if(isend==null){
		obj.isend=0;
		$("#isend").val(0);
	}else{
		$("#isend").val(isend);
	}
	var min_improvement=obj.min_improvement;
	if(min_improvement==null){
		obj.min_improvement=10E-7;
		$("#min_improvement").val(10E-7)
	}else{
		$("#min_improvement").val(min_improvement);
	}
	var tolerate_cycles=obj.tolerate_cycles;
	if(tolerate_cycles==null){
		obj.tolerate_cycles=50;
		$("#tolerate_cycles").val(50);
	}else{
		$("#tolerate_cycles").val(tolerate_cycles);
	}
	
}